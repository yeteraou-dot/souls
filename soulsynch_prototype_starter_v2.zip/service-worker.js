
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open('soulsynch-v2').then(cache => cache.addAll([
    '/', '/index.html', '/assets/app.css', '/assets/logo-192.png', '/assets/logo-512.png'
  ])));
});
self.addEventListener('fetch', (e) => {
  e.respondWith(caches.match(e.request).then(resp => resp || fetch(e.request)));
});
